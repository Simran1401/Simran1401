
$("#hover-img-1").hover(function () {
    $('#pricing-hover-col-1').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-2").hover(function () {
    $('#pricing-hover-col-2').show();
    $('#pricing-hover-col-1').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-3").hover(function () {
    $('#pricing-hover-col-3').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-1').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-4").hover(function () {
    $('#pricing-hover-col-4').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-1').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-5").hover(function () {
    $('#pricing-hover-col-5').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-1').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-6").hover(function () {
    $('#pricing-hover-col-6').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-1').hide();
    $('#pricing-hover-col-7').hide();
});
$("#hover-img-7").hover(function () {
    $('#pricing-hover-col-7').show();
    $('#pricing-hover-col-2').hide();
    $('#pricing-hover-col-3').hide();
    $('#pricing-hover-col-4').hide();
    $('#pricing-hover-col-5').hide();
    $('#pricing-hover-col-6').hide();
    $('#pricing-hover-col-1').hide();
});