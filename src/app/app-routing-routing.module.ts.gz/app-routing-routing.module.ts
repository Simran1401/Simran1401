import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './company/about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { ProductDietPlansComponent } from './our-product/product-diet-plans/product-diet-plans.component';
import { ProductJvScanComponent } from './our-product/product-jv-scan/product-jv-scan.component';
import { ResearchAndTechnologyComponent } from './company/research-and-technology/research-and-technology.component';
import { ResearchComponent } from './research/research.component';
import { CompanyComponent } from './company/company.component';
import { OurProductComponent } from './our-product/our-product.component';
import { PricingPageComponent } from './pricing-page/pricing-page.component';
import { WorkshopComponent } from './workshop/workshop.component';
import { WorkshopDetailsComponent } from './workshop-details/workshop-details.component';
import { WorkshopAccessComponent } from './workshop-access/workshop-access.component';
import { SingleProductPageComponent } from './single-product-page/single-product-page.component';
import { WorkshopAccessProgramsComponent } from './workshop-access/workshop-access-programs/workshop-access-programs.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PrivacyPoicyComponent } from './privacy-poicy/privacy-poicy.component';
import { TermsOfServicesComponent } from './terms-of-services/terms-of-services.component';
import { DisclaimerComponent } from './disclaimer/disclaimer.component';
import { CancellationPolicyComponent } from './cancellation-policy/cancellation-policy.component';
import { FaqComponent } from './faq/faq.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutPageComponent } from './checkout-page/checkout-page.component';
import { CheckoutDeliveryPageComponent } from './checkout-page/checkout-delivery-page/checkout-delivery-page.component';
import { PaymentMethodComponent } from './checkout-page/payment-method/payment-method.component';
import { PlaceOrderComponent } from './checkout-page/place-order/place-order.component';
import { ProfileComponent } from './profile/profile.component';
import { PersonalDetailsComponent } from './profile/personal-details/personal-details.component';
import { AddressesComponent } from './profile/addresses/addresses.component';
import { OrdersComponent } from './profile/orders/orders.component';
import { RefferAndEarnComponent } from './profile/reffer-and-earn/reffer-and-earn.component';
import { PractitionerRegisterationComponent } from './practitioner-registeration/practitioner-registeration.component';
import { AssociateRegisterationComponent } from './associate-registeration/associate-registeration.component';
import { BlogsComponent } from './blogs/blogs.component';
import { SingleBlogComponent } from './single-blog/single-blog.component';
import { profileGuard } from './guards/profile.guard';
import { DyProductsComponent } from './our-product/dy-products/dy-products.component';
import { DyProgrammesComponent } from './workshop-access/dy-programmes/dy-programmes.component';
import { checkOutDeactivateGuard } from './guards/checkOutCanDeactivate';
import { checkOutguard } from './guards/checkOutGuard';
import { EventsComponent } from './events/events.component';
import { EndUserPlansComponent } from './pricing-page/end-user-plans/end-user-plans.component';
import { PartnerWithUsComponent } from './pricing-page/partner-with-us/partner-with-us.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  {
    path: 'company', component: CompanyComponent,
    children: [
      { path: 'about-us', component: AboutUsComponent },
      { path: 'research-and-technology', component: ResearchAndTechnologyComponent },
      { path: '', redirectTo: 'about-us', pathMatch: 'full' }
    ]
  },
  { path: 'research', component: ResearchComponent },
  {
    path: 'our-products', component: OurProductComponent,
    children: [
      { path: 'product-jv-scan', component: ProductJvScanComponent },
      { path: 'product-diet-plans', component: ProductDietPlansComponent },
      { path: 'DY-product/:id', component: DyProductsComponent },
      { path: '', redirectTo: 'product-jv-scan', pathMatch: 'full' }
    ]
  },
  { path: 'pricing', component: PricingPageComponent },
  { path: 'pricing/end-user-plan', component: EndUserPlansComponent },
  { path: 'pricing/partner-with-us', component: PartnerWithUsComponent },
  { path: 'workshop-page', component: WorkshopComponent },
  { path: 'workshop-details', component: WorkshopDetailsComponent },
  {
    path: 'workshop-access', component: WorkshopAccessComponent,
    children: [
      { path: 'all-programs', component: WorkshopAccessProgramsComponent },
      { path: 'dy-workshopProgram/:id', component: DyProgrammesComponent },
      { path: '', redirectTo: 'all-programs', pathMatch: 'full' }
    ]
  },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'product-page/:id/:id', component: SingleProductPageComponent },
  { path: 'my-wishlist', component: WishlistComponent },
  { path: 'privacy-policy', component: PrivacyPoicyComponent },
  { path: 'terms-of-services', component: TermsOfServicesComponent },
  { path: 'disclaimer', component: DisclaimerComponent },
  { path: 'cancellation-policy', component: CancellationPolicyComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'cart', component: CartComponent },
  {
    path: 'checkout-page', canActivate: [profileGuard], component: CheckoutPageComponent, children: [
      { path: 'delivery-page', component: CheckoutDeliveryPageComponent },
      { path: 'payment-method', component: PaymentMethodComponent },
      { path: 'place-order', component: PlaceOrderComponent, canActivate: [checkOutguard], canDeactivate: [checkOutDeactivateGuard] },
      { path: '', redirectTo: 'delivery-page', pathMatch: 'full' }
    ]
  },
  {
    path: 'profile', canActivate: [profileGuard], component: ProfileComponent, children: [
      { path: 'personal-details', component: PersonalDetailsComponent },
      { path: 'addresses', component: AddressesComponent },
      { path: 'orders', component: OrdersComponent },
      { path: 'reffer-and-earn', component: RefferAndEarnComponent },
      { path: '', redirectTo: 'personal-details', pathMatch: 'full' }
    ]
  },
  { path: 'practitioner-registeration', component: PractitionerRegisterationComponent },
  { path: 'association-registeration', component: AssociateRegisterationComponent },
  { path: 'blogs', component: BlogsComponent },
  { path: 'event', component: EventsComponent },
  { path: 'single-blog/:id', component: SingleBlogComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingRoutingModule { }
