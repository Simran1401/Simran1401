import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AboutUsComponent } from './company/about-us/about-us.component';
import { ResearchAndTechnologyComponent } from './company/research-and-technology/research-and-technology.component';
import { ResearchComponent } from './research/research.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ProductJvScanComponent } from './our-product/product-jv-scan/product-jv-scan.component';
import { ProductDietPlansComponent } from './our-product/product-diet-plans/product-diet-plans.component';
import { SingleProductPageComponent } from './single-product-page/single-product-page.component';
import { PricingPageComponent } from './pricing-page/pricing-page.component';
import { WorkshopComponent } from './workshop/workshop.component';
import { WorkshopDetailsComponent } from './workshop-details/workshop-details.component';
import { WorkshopAccessComponent } from './workshop-access/workshop-access.component';
import { AppRoutingRoutingModule } from './app-routing-routing.module';
import { HomeComponent } from './home/home.component';
import { CompanyComponent } from './company/company.component';
import { OurProductComponent } from './our-product/our-product.component';
import { HomeSectionOneComponent } from './home/home-section-one/home-section-one.component';
import { HomeSectionTwoComponent } from './home/home-section-two/home-section-two.component';
import { HomeSectionThreeComponent } from './home/home-section-three/home-section-three.component';
import { HomeSectionFourComponent } from './home/home-section-four/home-section-four.component';
import { HomeSectionFiveComponent } from './home/home-section-five/home-section-five.component';
import { HomeSectionSixComponent } from './home/home-section-six/home-section-six.component';
import { HomeSectionSevenComponent } from './home/home-section-seven/home-section-seven.component';
import { HomeSectionEightComponent } from './home/home-section-eight/home-section-eight.component';
import { FooterComponent } from './footer/footer.component';
import { WorkshopAccessMenuComponent } from './workshop-access/workshop-access-menu/workshop-access-menu.component';
import { WorkshopAccessProgramsComponent } from './workshop-access/workshop-access-programs/workshop-access-programs.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PrivacyPoicyComponent } from './privacy-poicy/privacy-poicy.component';
import { TermsOfServicesComponent } from './terms-of-services/terms-of-services.component';
import { DisclaimerComponent } from './disclaimer/disclaimer.component';
import { CancellationPolicyComponent } from './cancellation-policy/cancellation-policy.component';
import { FaqComponent } from './faq/faq.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutPageComponent } from './checkout-page/checkout-page.component';
import { CheckoutDeliveryPageComponent } from './checkout-page/checkout-delivery-page/checkout-delivery-page.component';
import { PaymentMethodComponent } from './checkout-page/payment-method/payment-method.component';
import { PlaceOrderComponent } from './checkout-page/place-order/place-order.component';
import { ProfileComponent } from './profile/profile.component';
import { MenuComponent } from './profile/menu/menu.component';
import { PersonalDetailsComponent } from './profile/personal-details/personal-details.component';
import { OrdersComponent } from './profile/orders/orders.component';
import { AddressesComponent } from './profile/addresses/addresses.component';
import { RefferAndEarnComponent } from './profile/reffer-and-earn/reffer-and-earn.component';
import { PractitionerRegisterationComponent } from './practitioner-registeration/practitioner-registeration.component';
import { AssociateRegisterationComponent } from './associate-registeration/associate-registeration.component';
import { BlogsComponent } from './blogs/blogs.component';
import { SingleBlogComponent } from './single-blog/single-blog.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LogInOrSignUpComponent } from './header/log-in-or-sign-up/log-in-or-sign-up.component';
import { ShortLengthPipe } from './short-length.pipe';
import { DyProductsComponent } from './our-product/dy-products/dy-products.component';
import { DyProgrammesComponent } from './workshop-access/dy-programmes/dy-programmes.component';
import { CommonModule } from '@angular/common';
import { EventsComponent } from './events/events.component';
import { PartnerWithUsComponent } from './pricing-page/partner-with-us/partner-with-us.component';
import { EndUserPlansComponent } from './pricing-page/end-user-plans/end-user-plans.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AboutUsComponent,
    ResearchAndTechnologyComponent,
    ResearchComponent,
    ContactUsComponent,
    ProductJvScanComponent,
    ProductDietPlansComponent,
    SingleProductPageComponent,
    PricingPageComponent,
    WorkshopComponent,
    WorkshopDetailsComponent,
    WorkshopAccessComponent,
    HomeComponent,
    CompanyComponent,
    OurProductComponent,
    HomeSectionOneComponent,
    HomeSectionTwoComponent,
    HomeSectionThreeComponent,
    HomeSectionFourComponent,
    HomeSectionFiveComponent,
    HomeSectionSixComponent,
    HomeSectionSevenComponent,
    HomeSectionEightComponent,
    FooterComponent,
    WorkshopAccessMenuComponent,
    WorkshopAccessProgramsComponent,
    WishlistComponent,
    PrivacyPoicyComponent,
    TermsOfServicesComponent,
    DisclaimerComponent,
    CancellationPolicyComponent,
    FaqComponent,
    CartComponent,
    CheckoutPageComponent,
    CheckoutDeliveryPageComponent,
    PaymentMethodComponent,
    PlaceOrderComponent,
    ProfileComponent,
    MenuComponent,
    PersonalDetailsComponent,
    OrdersComponent,
    AddressesComponent,
    RefferAndEarnComponent,
    PractitionerRegisterationComponent,
    AssociateRegisterationComponent,
    BlogsComponent,
    SingleBlogComponent,
    LogInOrSignUpComponent,
    ShortLengthPipe,
    DyProductsComponent,
    DyProgrammesComponent,
    EventsComponent,
    PartnerWithUsComponent,
    EndUserPlansComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingRoutingModule,
    ReactiveFormsModule,
    SlickCarouselModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
