import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associate-registeration',
  templateUrl: './associate-registeration.component.html',
  styleUrls: ['./associate-registeration.component.css']
})
export class AssociateRegisterationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
