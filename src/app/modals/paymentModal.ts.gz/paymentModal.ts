export class paymentAddData {
  razorpay_payment_id: string;
  razorpay_signature: string;
  razorpay_order_id: string;
}
