export class productModal {
  constructor(
    public id: number,
    public image: string,
    public name: string,
    public price: string,
  ) { }
}
