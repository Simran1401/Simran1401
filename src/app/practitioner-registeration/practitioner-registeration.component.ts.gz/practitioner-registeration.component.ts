import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practitioner-registeration',
  templateUrl: './practitioner-registeration.component.html',
  styleUrls: ['./practitioner-registeration.component.css']
})
export class PractitionerRegisterationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
