import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner-with-us',
  templateUrl: './partner-with-us.component.html',
  styleUrls: ['./partner-with-us.component.css']
})
export class PartnerWithUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
