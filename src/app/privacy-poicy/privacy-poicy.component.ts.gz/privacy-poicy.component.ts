import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privacy-poicy',
  templateUrl: './privacy-poicy.component.html',
  styleUrls: ['./privacy-poicy.component.css']
})
export class PrivacyPoicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
