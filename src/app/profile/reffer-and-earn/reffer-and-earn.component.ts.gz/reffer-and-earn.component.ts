import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reffer-and-earn',
  templateUrl: './reffer-and-earn.component.html',
  styleUrls: ['./reffer-and-earn.component.css']
})
export class RefferAndEarnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
