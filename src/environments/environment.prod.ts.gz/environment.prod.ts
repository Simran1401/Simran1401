export const environment = {
  production: true,
  apiUrl: 'https://apijv.gftpl.in'
};
